$(document).ready(function() {
    // Initialize variables for counting shapes and operation status
    let shapeCount = 0;
    let adding = false;
    let removing = false;

    // Listen for the add shape button click event
    $('#addShapeBtn').click(async function() {
        // Prevent overlapping operations
        if (adding || removing) return;
        adding = true;

        // Get shape properties from user input
        let shapeType = $('#shapeType').val();
        let shapeColor = $('#shapeColor').val();
        let shapeSize = parseInt($('#shapeSize').val());

        // Create a new shape element
        let $shape = $('<div class="shape"></div>');

        // Adjust shape based on selected type (square or circle)
        if (shapeType === 'circle') {
            $shape.css({
                'border-radius': '50%'
            });
        }

        // Set CSS properties for the shape
        $shape.css({
            'background-color': shapeColor,
            'width': shapeSize + 'px',
            'height': shapeSize + 'px',
            'left': '-100px' // Start off-screen to the left
        });

        // Add the shape to the container
        $('.shapeContainer').append($shape);

        // Place the shape in the correct position with animation
        placeShape($shape, shapeSize);

        shapeCount++;
        adding = false;
    });

    // Listen for the remove shape button click event
    $('#removeShapeBtn').click(async function() {
        // Prevent overlapping operations
        if (adding || removing) return;
        removing = true;

        // Select and remove the last added shape if any
        let $lastShape = $('.shapeContainer .shape').last();
        if ($lastShape.length) {
            await $lastShape.fadeOut('fast').promise(); // Fade out animation
            $lastShape.remove(); // Remove the shape from DOM
            shapeCount--;
        }
        removing = false;
    });

    // Function to place the shape in the container
    function placeShape($shape, shapeSize) {
        let containerWidth = $('.shapeContainer').width(); // Get container width
        let spaceBetweenShapes = 20; // Space between shapes
        let left = 0;
        let top = 0;
        let maxHeightInRow = 0;

        // Iterate over existing shapes to determine the position for the new shape
        $('.shapeContainer .shape').each(function() {
            let $existingShape = $(this);
            let existingShapeWidth = $existingShape.outerWidth(true);
            let existingShapeHeight = $existingShape.outerHeight(true);

            // Check if the new shape exceeds the container width, move to next row
            if ((left + shapeSize + spaceBetweenShapes) > containerWidth) {
                left = 0;
                top += maxHeightInRow + spaceBetweenShapes;
                maxHeightInRow = 0;
            }

            // Update the maximum height of shapes in the current row
            maxHeightInRow = Math.max(maxHeightInRow, existingShapeHeight);
            left += existingShapeWidth + spaceBetweenShapes;
        });

        // Set the final position for the new shape
        $shape.css({
            'left': left + 'px',
            'top': top + 'px'
        });

        // Apply the transition to move the shape into view
        setTimeout(function() {
            $shape.css('left', left + 'px');
        }, 10); // Small delay to trigger CSS transition
    }
});
