<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Page</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <h1>My PHP Page</h1>
    
    <?php
        // a. Menampilkan "Hello World"
        echo "<p>Hello World</p>";

        // b. Menampilkan list berisi nama bulan dari Januari hingga Desember
        $months = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
        echo "<h2>Daftar Bulan</h2>";
        echo "<ul>";
        foreach ($months as $month) {
            echo "<li>$month</li>";
        }
        echo "</ul>";

        // c. Menampilkan sebuah table berisi apapun
        echo "<h2>Contoh Tabel</h2>";
        echo "<table>";
        echo "<tr><th>Nama</th><th>Usia</th><th>Kota</th><th>Status</th></tr>";
        echo "<tr><td>Aurelia</td><td>19</td><td>Makassar</td><td>Mahasiswi</td></tr>";
        echo "<tr><td>Lili</td><td>18</td><td>Bali</td><td>Mahasisiwi</td></tr>";
        echo "<tr><td>Lulu</td><td>17</td><td>Jakarta</td><td>Mahasisiwi</td></tr>";
        echo "</table>";
    ?>

    <!-- d. Menampilkan formulir -->
    <h2>Formulir Kontak</h2>
    <form action="" method="post">
        <label for="name">Nama:</label>
        <input type="text" id="name" name="name" required><br><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>
        <label for="message">Pesan:</label><br>
        <textarea id="message" name="message" rows="4" cols="50" required></textarea><br><br>
        <input type="submit" value="Kirim">
    </form>
</body>
</html>

